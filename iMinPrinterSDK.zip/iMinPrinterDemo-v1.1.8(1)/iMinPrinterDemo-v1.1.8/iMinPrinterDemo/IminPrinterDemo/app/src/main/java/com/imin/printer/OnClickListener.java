package com.imin.printer;

import android.view.View;


public interface OnClickListener {
    void onClick(View view, int pos, Object o);
}
